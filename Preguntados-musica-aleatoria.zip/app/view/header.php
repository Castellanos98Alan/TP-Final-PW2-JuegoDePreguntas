<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <?php
    $baseDir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
    $baseUrl = ($baseDir === '' || $baseDir === '/' || $baseDir === '\\') ? '/' : $baseDir . '/';
    ?>
    <base href="<?= htmlspecialchars($baseUrl) ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preguntados Anime</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&family=Roboto:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html {
            -webkit-text-size-adjust: 100%;
            text-size-adjust: 100%;
        }

        /* Medios nunca más anchos que su contenedor (imágenes, audio, canvas de gráficos) */
        img, video, canvas, svg {
            max-width: 100%;
        }

        audio {
            width: 100%;
            max-width: 100%;
        }

        body {
            min-height: 100vh;
            min-height: 100dvh; /* en celular 100vh incluye la barra del navegador */
            display: flex;
            flex-direction: column;
            font-family: 'Roboto', sans-serif;
            color: #F3F5FA;
            background:
                    radial-gradient(ellipse at 15% 20%, rgba(31, 91, 160, 0.45), transparent 38%),
                    radial-gradient(ellipse at 85% 75%, rgba(18, 57, 110, 0.35), transparent 40%),
                    linear-gradient(135deg, #071329, #10294D 55%, #071329);
            background-attachment: fixed;
            overflow-x: hidden;
            position: relative;
        }

        body::before,
        body::after {
            content: "";
            position: fixed;
            pointer-events: none;
            opacity: 0.5;
            z-index: 0;
        }

        body::before {
            width: 240px;
            height: 240px;
            top: 5%;
            left: -90px;
            border: 1px solid rgba(212, 175, 85, 0.5);
            border-radius: 50%;
            box-shadow: 0 0 0 18px rgba(212, 175, 85, 0.04),
            0 0 0 38px rgba(212, 175, 85, 0.03);
        }

        body::after {
            width: 180px;
            height: 180px;
            bottom: -90px;
            right: -50px;
            border: 1px solid #D4AF55;
            transform: rotate(45deg);
        }

        /* HEADER */
        .site-header {
            width: 100%;
            background: rgba(7, 20, 42, 0.95);
            border-bottom: 1px solid rgba(185, 139, 59, 0.4);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(8px);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 14px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 10px 15px;
        }

        .brand-link {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            min-width: 0;
        }

        .brand-emblem {
            width: 38px;
            height: 38px;
            border: 2px solid #D4AF55;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #F1CD73;
            font-size: 20px;
            flex-shrink: 0;
        }

        .brand-text h1 {
            font-family: 'Permanent Marker', cursive;
            font-size: 20px;
            color: #F1CD73;
            letter-spacing: 1px;
            line-height: 1;
        }

        .brand-text span {
            font-size: 10px;
            letter-spacing: 2.5px;
            color: #B6C9E6;
            font-weight: 700;
            display: block;
            margin-top: 2px;
        }

        .nav-actions {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            flex-wrap: wrap;
            gap: 12px;
            min-width: 0;
        }

        /* BOTÓN DE PERFIL CON FOTO REAL Y USERNAME */
        .header-user-btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 4px 14px 4px 5px;
            background: rgba(16, 39, 73, 0.55);
            border: 1px solid rgba(212, 175, 85, 0.45);
            border-radius: 25px;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .header-user-btn:hover {
            border-color: #F1CD73;
            background: rgba(212, 175, 85, 0.15);
            box-shadow: 0 0 12px rgba(241, 205, 115, 0.25);
            transform: translateY(-1px);
        }

        .header-user-avatar {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #D4AF55;
            box-shadow: 0 0 6px rgba(212, 175, 85, 0.4);
            display: block;
            flex-shrink: 0;
        }

        .header-user-name {
            color: #F1CD73;
            font-weight: 600;
            font-size: 14px;
            letter-spacing: 0.5px;
            line-height: 1;
            max-width: 120px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .btn-link {
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            white-space: nowrap;
        }

        .btn-panel {
            border: 1px solid #D4AF55;
            color: #F1CD73;
            background: rgba(212, 175, 85, 0.12);
        }

        .btn-panel:hover {
            background: #D4AF55;
            color: #0A1A33;
        }

        .btn-outline {
            border: 1px solid #315B91;
            color: #DCE6F8;
            background: rgba(16, 39, 73, 0.4);
        }

        .btn-outline:hover {
            border-color: #D4AF55;
            color: #F1CD73;
        }

        .btn-gold {
            background: linear-gradient(110deg, #F4D47D, #C99A3D);
            color: #0A1A33;
            border: 1px solid #F5D78A;
        }

        .btn-gold:hover {
            filter: brightness(1.08);
            transform: translateY(-1px);
        }

        /* ÁREA CENTRAL */
        .main-content {
            flex: 1;
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            position: relative;
            z-index: 1;
        }

        .main-content > * {
            min-width: 0;
        }

        /* RESPONSIVE */
        @media (max-width: 768px) {
            /* background-attachment:fixed falla/va lento en iOS y Android */
            body {
                background-attachment: scroll;
            }
        }

        @media (max-width: 600px) {
            .header-container {
                padding: 10px 12px;
                gap: 8px;
            }
            .brand-text span {
                display: none;
            }
            .brand-text h1 {
                font-size: 17px;
            }
            .header-user-name {
                display: none;
            }
            .header-user-btn {
                padding: 3px;
            }
            .nav-actions {
                gap: 6px;
            }
            .btn-link {
                padding: 8px 10px;
                font-size: 12px;
                min-height: 40px; /* área táctil cómoda */
            }
            .main-content {
                padding: 20px 12px;
            }
            /* decoración fija: no aporta en pantallas chicas */
            body::before,
            body::after {
                display: none;
            }

            /* iOS hace zoom automático en campos con letra menor a 16px */
            input:not([type="radio"]):not([type="checkbox"]):not([type="range"]),
            select,
            textarea {
                font-size: 16px !important;
            }
        }

        /* Celulares angostos (320-480): solo el emblema, el nombre del sitio sobra */
        @media (max-width: 480px) {
            .brand-text {
                display: none;
            }
        }
    </style>
    <link rel="stylesheet" href="public/css/musicaLobby.css">
    <script defer src="public/js/musicaLobby.js"></script>
</head>
<body>

<header class="site-header">
    <div class="header-container">
        <a href="lobby" class="brand-link" aria-label="Preguntados Anime - ir al lobby">
            <div class="brand-emblem" aria-hidden="true">✦</div>
            <div class="brand-text">
                <h1>PREGUNTADOS</h1>
                <span>ANIME EDITION</span>
            </div>
        </a>

        <nav class="nav-actions">
            <?php if (isset($_SESSION['usuario'])): ?>
                <?php
                $rol = (int)($_SESSION['rol'] ?? $_SESSION['id_rol'] ?? 0);
                $foto = !empty($_SESSION['foto_perfil']) ? ltrim($_SESSION['foto_perfil'], '/') : 'FondoPerfilLuffy.png';
                $rutaFoto = 'public/' . $foto;
                ?>

                <!-- Solo visible para rol 2 (Editor) -->
                <?php if ($rol === 2): ?>
                    <a href="editor" class="btn-link btn-panel">Editor</a>
                <?php endif; ?>

                <!-- Solo visible para rol 3 (Administrador) -->
                <?php if ($rol === 3): ?>
                    <a href="admin" class="btn-link btn-panel">Admin</a>
                <?php endif; ?>

                <a href="perfil" class="header-user-btn" title="Ver mi perfil">
                    <img src="<?= htmlspecialchars($rutaFoto) ?>"
                         alt="Foto de <?= htmlspecialchars($_SESSION['usuario']) ?>"
                         class="header-user-avatar"
                         onerror="this.onerror=null; this.src='public/FondoPerfilLuffy.png';">
                    <span class="header-user-name"><?= htmlspecialchars($_SESSION['usuario']) ?></span>
                </a>
                <a href="login/logout" class="btn-link btn-outline">Cerrar Sesión</a>
                <?php if ($view === 'lobby'): ?>
                    <div class="musica-config" id="musicaConfig">
                        <button type="button" id="abrirMusica" aria-label="Configurar sonido" aria-expanded="false" aria-controls="panelMusica">⚙</button>
                        <section id="panelMusica" hidden aria-label="Configuración de sonido">
                            <h2>Configuración de sonido</h2>
                            <label for="volumenMusica">Volumen <output id="valorMusica">30%</output></label>
                            <input id="volumenMusica" type="range" min="0" max="100" value="30">
                            <label><input type="checkbox" id="silenciarMusica"> Silenciar música</label>
                            <button type="button" id="reproducirMusica">Reproducir música</button>
                            <p id="estadoMusica" role="status"></p>
                        </section>
                        <audio id="musicaFondo" preload="none"></audio>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <a href="login" class="btn-link btn-outline">Ingresar</a>
                <a href="registro" class="btn-link btn-gold">Registrarse</a>
            <?php endif; ?>
        </nav>
    </div>
</header>

<main class="main-content">